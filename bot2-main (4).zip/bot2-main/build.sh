#!/bin/bash
pip install -e .
